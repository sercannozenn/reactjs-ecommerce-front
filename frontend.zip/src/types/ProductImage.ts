export interface ProductImage {
    id: number;
    product_id: number;
    image_path: string;
    is_featured: boolean;
}
