export interface ProductPrice {
    price: string;
    price_discount: string | null;
}
